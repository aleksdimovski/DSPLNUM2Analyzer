features int[0,99] A;


int main() {
  int y=[0,4];
  if (A<2) y=y+1; else y=y-1;
  A=y+1;
  y=A+1;
  A=5;
  return 0;
}