features int[-9,9] n;
//features int[0,6] A2;


int main()
{
//  int n = [-9,9];

	
  int x=n, y=0;
  while(n>0)
  {
    n--;
    y++;
  }
  assert(y==x);
}

